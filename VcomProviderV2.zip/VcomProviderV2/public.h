#ifndef _PUBLIC_H_
#define _PUBLIC_H_
#pragma once

// Include the Microsoft serial.h for IOCTL_SERIAL_* compatibility.
#include "serial.h"

// {8E25B239-36F1-4568-B6A5-69A6272555E7}
DEFINE_GUID(GUID_DEVINTERFACE_VCOM_CONTROL,
	0x8e25b239, 0x36f1, 0x4568, 0xb6, 0xa5, 0x69, 0xa6, 0x27, 0x25, 0x55, 0xe7);

// Custom device type for our IOCTLs
#define FILE_DEVICE_VCOM 0x8000

// Custom IOCTLs for the data pipe between the driver and the client app
#define IOCTL_VCOM_GET_OUTGOING   CTL_CODE(FILE_DEVICE_VCOM, 0x801, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
#define IOCTL_VCOM_PUSH_INCOMING  CTL_CODE(FILE_DEVICE_VCOM, 0x802, METHOD_IN_DIRECT,  FILE_ANY_ACCESS)
#define IOCTL_VCOM_START          CTL_CODE(FILE_DEVICE_VCOM, 0x803, METHOD_BUFFERED,   FILE_ANY_ACCESS)
#define IOCTL_VCOM_STOP           CTL_CODE(FILE_DEVICE_VCOM, 0x804, METHOD_BUFFERED,   FILE_ANY_ACCESS)

#endif // _PUBLIC_H_