#pragma once

EVT_WDF_DRIVER_DEVICE_ADD VcomEvtDeviceAdd;

